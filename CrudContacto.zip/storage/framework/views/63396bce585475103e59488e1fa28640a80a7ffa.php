<?php $__env->startSection('content'); ?>
<div class="container">
     <?php if(session('message')): ?>
    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">ver <?php echo e($contacto->nombre); ?></div>
                <div class="card-body">
                    <h2><?php echo e($contacto->nombre. ' '.$contacto->apellido); ?></h2><br>
                    <p>el candidato posee la edad de   <?php echo e($contacto->edad); ?> años</p>
                    <p>dejo el siguiente mensaje <br><?php echo e($contacto->mensaje); ?></p>
                    <br>
                    <p>nos podemos contactar con el a traves del <br> <span class="resaltado">correo:</span> <a href="mailto:<?php echo e($contacto->correo); ?>"><?php echo e($contacto->correo); ?></a> <br>o del <br> <span class="resaltado">Telefono:</span> <a href="tel:+51<?php echo e($contacto->telefono); ?>"><?php echo e($contacto->telefono); ?></a> </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>