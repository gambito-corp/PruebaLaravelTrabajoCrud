<?php $__env->startSection('content'); ?>
<div class="container">
     <?php if(session('message')): ?>
    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Editar <?php echo e($contacto->nombre); ?></div>
                <div class="card-body">
                    <form name="contacto" action="<?php echo e(route('contacto.actualizar')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($contacto->id); ?>">
                        <div class="form-group">
                            <label for="nombre">Nombre*: </label>                        
                            <input type="text" name="nombre" size="40" class="form-control <?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" value="<?php echo e($contacto->nombre); ?>"/>


                            <?php if($errors->has('nombre')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('nombre')); ?></strong>
                                </span>
                                <?php endif; ?>                                                                
                        </div>

                        <div class="form-group">
                            <label for="apellido">apellido*: </label>                        
                            <input type="text" name="apellido" size="40" class="form-control <?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" value="<?php echo e($contacto->apellido); ?>"/>

                            <?php if($errors->has('apellido')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('apellido')); ?></strong>
                                </span>
                                <?php endif; ?>                                                                
                        </div>


                        <div class="form-group">
                            <label for="edad">edad*: </label>                        
                            <input type="number" name="edad" size="3" class="form-control <?php echo e($errors->has('edad') ? ' is-invalid' : ''); ?>" value="<?php echo e($contacto->edad); ?>"/>

                            <?php if($errors->has('edad')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('edad')); ?></strong>
                                </span>
                                <?php endif; ?>                                                                
                        </div>

                        <div class="form-group">
                            <label for="telefono">telefono*: </label>                        
                            <input type="tel" name="telefono" size="11" class="form-control <?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" value="<?php echo e($contacto->telefono); ?>"/>

                            <?php if($errors->has('telefono')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('telefono')); ?></strong>
                                </span>
                                <?php endif; ?>                                                                
                        </div>

                        <div class="form-group">
                            <label for="correo">correo*: </label>                        
                            <input type="email" name="correo" size="40" class="form-control <?php echo e($errors->has('correo') ? ' is-invalid' : ''); ?>" value="<?php echo e($contacto->correo); ?>"/>

                            <?php if($errors->has('correo')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('correo')); ?></strong>
                                </span>
                                <?php endif; ?>                                                                
                        </div>

                        <div class="form-group">
                            <label for="mensaje">mensaje*: </label>                        
                            <textarea name="mensaje" class="form-control <?php echo e($errors->has('mensaje') ? ' is-invalid' : ''); ?>"  required/><?php echo e($contacto->mensaje); ?></textarea>

                            <?php if($errors->has('mensaje')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('mensaje')); ?></strong>
                                </span>
                                <?php endif; ?>                                        
                        </div>

                            <input type="submit" value="editar" class="btn btn-success" />

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>